package com.example.activity_2_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
